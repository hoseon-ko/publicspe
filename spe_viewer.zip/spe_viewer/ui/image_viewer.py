"""
image_viewer.py
pyqtgraph ImageView 기반 이미지 뷰어
ROI (Line, Box), X/Y 프로파일 지원
"""

import numpy as np
import pyqtgraph as pg
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox
from PyQt6.QtCore import pyqtSignal, Qt


# pyqtgraph 다크 테마 설정
pg.setConfigOption('background', '#1a1a2e')
pg.setConfigOption('foreground', '#e0e0e0')
pg.setConfigOption('antialias', True)


class ImageViewer(QWidget):
    """
    메인 이미지 뷰어.
    - pyqtgraph ImageView: 확대/축소/패닝/컬러맵 내장
    - LineSegmentROI: 라인 프로파일용
    - RectROI: 박스 프로파일용
    """

    # 시그널 (프로파일 데이터 → 플롯 패널로 전달)
    line_profile_updated = pyqtSignal(object)   # np.ndarray 1D
    box_profile_updated = pyqtSignal(object, object)  # (x_mean, y_mean)
    pixel_info_updated = pyqtSignal(int, int, float)  # (x, y, value)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_image: np.ndarray | None = None
        self._roi_mode = None   # 'line' | 'box' | 'xprofile' | 'yprofile'
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # 상단 툴바 (ROI 모드 선택)
        toolbar = QHBoxLayout()

        roi_label = QLabel("ROI:")
        roi_label.setStyleSheet("color: #a0a0b0; font-size: 11px;")
        toolbar.addWidget(roi_label)

        self.roi_combo = QComboBox()
        self.roi_combo.addItems(["None", "Line Profile", "Box Profile", "X Profile", "Y Profile"])
        self.roi_combo.setFixedWidth(130)
        self.roi_combo.currentTextChanged.connect(self._on_roi_mode_changed)
        toolbar.addWidget(self.roi_combo)

        cmap_label = QLabel("  Colormap:")
        cmap_label.setStyleSheet("color: #a0a0b0; font-size: 11px;")
        toolbar.addWidget(cmap_label)

        self.cmap_combo = QComboBox()
        self.cmap_combo.addItems(["viridis", "plasma", "inferno", "magma", "grey", "hot"])
        self.cmap_combo.setFixedWidth(100)
        self.cmap_combo.currentTextChanged.connect(self._on_cmap_changed)
        toolbar.addWidget(self.cmap_combo)

        toolbar.addStretch()

        # 픽셀 정보 표시
        self.pixel_label = QLabel("X: -  Y: -  Val: -")
        self.pixel_label.setStyleSheet("color: #e94560; font-size: 11px; font-weight: bold;")
        toolbar.addWidget(self.pixel_label)

        layout.addLayout(toolbar)

        # pyqtgraph ImageView
        self.image_view = pg.ImageView()
        self.image_view.ui.roiBtn.hide()      # 기본 ROI 버튼 숨김
        self.image_view.ui.menuBtn.hide()     # 메뉴 버튼 숨김

        # 히스토그램 스타일
        self.image_view.getHistogramWidget().setBackground('#16213e')

        layout.addWidget(self.image_view)

        # ROI 초기화
        self._line_roi: pg.LineSegmentROI | None = None
        self._box_roi: pg.RectROI | None = None

        # 마우스 이동 시 픽셀 정보
        self.image_view.scene.sigMouseMoved.connect(self._on_mouse_moved)

    # ─────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────

    def set_image(self, image: np.ndarray):
        """이미지 업데이트"""
        self._current_image = image
        # autoRange=False: 뷰 범위 유지 (프레임 전환 시 유용)
        self.image_view.setImage(
            image.T,  # pyqtgraph는 (x, y) 순서라 transpose 필요
            autoRange=False,
            autoLevels=True,
            autoHistogramRange=True
        )
        self._update_roi_profile()

    def set_image_first(self, image: np.ndarray):
        """첫 이미지 로드 시 - autoRange True"""
        self._current_image = image
        self.image_view.setImage(
            image.T,
            autoRange=True,
            autoLevels=True,
            autoHistogramRange=True
        )
        self._set_colormap(self.cmap_combo.currentText())

    # ─────────────────────────────────────────
    # ROI 모드
    # ─────────────────────────────────────────

    def _on_roi_mode_changed(self, mode_text: str):
        self._remove_all_roi()

        if mode_text == "Line Profile":
            self._roi_mode = 'line'
            self._add_line_roi()
        elif mode_text == "Box Profile":
            self._roi_mode = 'box'
            self._add_box_roi()
        elif mode_text == "X Profile":
            self._roi_mode = 'xprofile'
            self._compute_x_profile()
        elif mode_text == "Y Profile":
            self._roi_mode = 'yprofile'
            self._compute_y_profile()
        else:
            self._roi_mode = None

    def _add_line_roi(self):
        """드래그 가능한 라인 ROI 추가"""
        if self._current_image is None:
            return
        h, w = self._current_image.shape[:2]
        # 이미지 중앙에 가로 라인 배치
        self._line_roi = pg.LineSegmentROI(
            positions=[[w * 0.2, h * 0.5], [w * 0.8, h * 0.5]],
            pen=pg.mkPen('#e94560', width=2)
        )
        self.image_view.addItem(self._line_roi)
        self._line_roi.sigRegionChanged.connect(self._update_roi_profile)
        self._update_roi_profile()

    def _add_box_roi(self):
        """드래그/리사이즈 가능한 박스 ROI 추가"""
        if self._current_image is None:
            return
        h, w = self._current_image.shape[:2]
        size = min(w, h) * 0.3
        self._box_roi = pg.RectROI(
            pos=[w * 0.35, h * 0.35],
            size=[size, size],
            pen=pg.mkPen('#e94560', width=2)
        )
        self.image_view.addItem(self._box_roi)
        self._box_roi.sigRegionChanged.connect(self._update_roi_profile)
        self._update_roi_profile()

    def _remove_all_roi(self):
        if self._line_roi is not None:
            self.image_view.removeItem(self._line_roi)
            self._line_roi = None
        if self._box_roi is not None:
            self.image_view.removeItem(self._box_roi)
            self._box_roi = None

    # ─────────────────────────────────────────
    # 프로파일 계산
    # ─────────────────────────────────────────

    def _update_roi_profile(self):
        if self._current_image is None:
            return

        if self._roi_mode == 'line' and self._line_roi is not None:
            self._compute_line_profile()
        elif self._roi_mode == 'box' and self._box_roi is not None:
            self._compute_box_profile()

    def _compute_line_profile(self):
        """라인 ROI를 따라 강도 프로파일 계산"""
        try:
            # getArrayRegion: ROI를 따라 보간된 1D 배열 반환
            data = self._line_roi.getArrayRegion(
                self._current_image.T,
                self.image_view.getImageItem(),
                axes=(0, 1)
            )
            if data is not None and data.ndim >= 1:
                profile = data.mean(axis=1) if data.ndim == 2 else data
                self.line_profile_updated.emit(profile)
        except Exception:
            pass

    def _compute_box_profile(self):
        """박스 ROI 영역의 X/Y 평균 프로파일 계산"""
        try:
            data = self._box_roi.getArrayRegion(
                self._current_image.T,
                self.image_view.getImageItem(),
                axes=(0, 1)
            )
            if data is not None and data.ndim == 2:
                x_mean = data.mean(axis=1)  # 행 방향 평균 → X 프로파일
                y_mean = data.mean(axis=0)  # 열 방향 평균 → Y 프로파일
                self.box_profile_updated.emit(x_mean, y_mean)
        except Exception:
            pass

    def _compute_x_profile(self):
        """전체 이미지 X축(열) 평균 프로파일"""
        if self._current_image is None:
            return
        profile = self._current_image.mean(axis=0)
        self.line_profile_updated.emit(profile)

    def _compute_y_profile(self):
        """전체 이미지 Y축(행) 평균 프로파일"""
        if self._current_image is None:
            return
        profile = self._current_image.mean(axis=1)
        self.line_profile_updated.emit(profile)

    # ─────────────────────────────────────────
    # 컬러맵
    # ─────────────────────────────────────────

    def _on_cmap_changed(self, name: str):
        self._set_colormap(name)

    def _set_colormap(self, name: str):
        try:
            cmap = pg.colormap.get(name, source='matplotlib')
            self.image_view.setColorMap(cmap)
        except Exception:
            pass  # matplotlib 없으면 기본 유지

    # ─────────────────────────────────────────
    # 마우스 정보
    # ─────────────────────────────────────────

    def _on_mouse_moved(self, pos):
        if self._current_image is None:
            return
        try:
            img_item = self.image_view.getImageItem()
            mouse_point = img_item.mapFromScene(pos)
            x, y = int(mouse_point.x()), int(mouse_point.y())
            h, w = self._current_image.shape[:2]
            if 0 <= x < w and 0 <= y < h:
                val = self._current_image[y, x]
                self.pixel_label.setText(f"X: {x}  Y: {y}  Val: {val:.1f}")
                self.pixel_info_updated.emit(x, y, float(val))
        except Exception:
            pass
