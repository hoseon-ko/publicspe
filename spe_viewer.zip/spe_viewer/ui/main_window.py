"""
main_window.py
메인 윈도우 - 전체 레이아웃 조립
"""

import numpy as np
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout,
    QDockWidget, QFileDialog, QStatusBar,
    QProgressBar, QLabel, QToolBar, QMessageBox
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QAction, QIcon, QFont

from ui.image_viewer import ImageViewer
from ui.file_list_panel import FileListPanel, SpeFileItem
from ui.plot_panel import PlotPanel
from core.async_worker import SpeLoadWorker


class MainWindow(QMainWindow):
    def __init__(self, spe_class=None):
        super().__init__()
        self.spe_class = spe_class   # 외부에서 주입받는 SPE 클래스
        self._workers: list[SpeLoadWorker] = []

        self.setWindowTitle("SPE Viewer")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)

        self._setup_ui()
        self._setup_toolbar()
        self._setup_statusbar()
        self._connect_signals()

    # ─────────────────────────────────────────
    # UI 구성
    # ─────────────────────────────────────────

    def _setup_ui(self):
        # 중앙 위젯: 이미지 뷰어
        self.image_viewer = ImageViewer()
        self.setCentralWidget(self.image_viewer)

        # ── 좌측 Dock: 파일 리스트 ──
        self.file_list_panel = FileListPanel()
        self.dock_files = QDockWidget("Files", self)
        self.dock_files.setWidget(self.file_list_panel)
        self.dock_files.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
        )
        self.dock_files.setMinimumWidth(200)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.dock_files)

        # ── 하단 Dock: 프로파일 플롯 ──
        self.plot_panel = PlotPanel("Profile")
        self.dock_plot = QDockWidget("Profile Plot", self)
        self.dock_plot.setWidget(self.plot_panel)
        self.dock_plot.setAllowedAreas(
            Qt.DockWidgetArea.BottomDockWidgetArea | Qt.DockWidgetArea.TopDockWidgetArea |
            Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
        )
        self.dock_plot.setMinimumHeight(180)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.dock_plot)

    def _setup_toolbar(self):
        toolbar = QToolBar("Main Toolbar")
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(16, 16))
        self.addToolBar(toolbar)

        # 파일 열기
        act_open = QAction("📂  Open SPE", self)
        act_open.setShortcut("Ctrl+O")
        act_open.triggered.connect(self._on_open_files)
        toolbar.addAction(act_open)

        toolbar.addSeparator()

        # Dock 토글
        act_toggle_files = QAction("📋  Files", self)
        act_toggle_files.setCheckable(True)
        act_toggle_files.setChecked(True)
        act_toggle_files.triggered.connect(self.dock_files.setVisible)
        toolbar.addAction(act_toggle_files)

        act_toggle_plot = QAction("📈  Plot", self)
        act_toggle_plot.setCheckable(True)
        act_toggle_plot.setChecked(True)
        act_toggle_plot.triggered.connect(self.dock_plot.setVisible)
        toolbar.addAction(act_toggle_plot)

        toolbar.addSeparator()

        # 뷰 리셋
        act_reset = QAction("⟳  Reset View", self)
        act_reset.triggered.connect(self._on_reset_view)
        toolbar.addAction(act_reset)

    def _setup_statusbar(self):
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #a0a0b0;")
        self.status_bar.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedWidth(150)
        self.progress_bar.setFixedHeight(14)
        self.progress_bar.setVisible(False)
        self.status_bar.addPermanentWidget(self.progress_bar)

    def _connect_signals(self):
        # 파일 리스트 → 이미지 뷰어
        self.file_list_panel.file_selected.connect(self._on_file_selected)
        self.file_list_panel.frame_changed.connect(self._on_frame_changed)

        # 이미지 뷰어 → 플롯 패널
        self.image_viewer.line_profile_updated.connect(self._on_line_profile)
        self.image_viewer.box_profile_updated.connect(self._on_box_profile)
        self.image_viewer.pixel_info_updated.connect(self._on_pixel_info)

    # ─────────────────────────────────────────
    # 파일 오픈
    # ─────────────────────────────────────────

    def _on_open_files(self):
        if self.spe_class is None:
            QMessageBox.warning(self, "Warning", "SPE 클래스가 설정되지 않았습니다.\nmain.py에서 spe_class를 주입해주세요.")
            return

        paths, _ = QFileDialog.getOpenFileNames(
            self, "Open SPE Files", "", "SPE Files (*.spe);;All Files (*)"
        )
        for path in paths:
            self._load_spe_async(path)

    def _load_spe_async(self, filepath: str):
        """비동기 SPE 로딩"""
        self.status_label.setText(f"Loading: {filepath}")
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        worker = SpeLoadWorker(filepath, self.spe_class)
        worker.progress.connect(self.progress_bar.setValue)
        worker.finished.connect(self._on_spe_loaded)
        worker.error.connect(self._on_load_error)
        worker.finished.connect(lambda: self.progress_bar.setVisible(False))

        self._workers.append(worker)
        worker.start()

    def _on_spe_loaded(self, filepath: str, spe_obj):
        """SPE 로드 완료 콜백"""
        # 프레임 수 파악
        num_frames = 1
        if hasattr(spe_obj, 'num_frames'):
            num_frames = spe_obj.num_frames
        elif hasattr(spe_obj, 'data'):
            data = spe_obj.data
            if isinstance(data, np.ndarray) and data.ndim == 3:
                num_frames = data.shape[0]

        self.file_list_panel.add_file(filepath, spe_obj, num_frames)
        self.status_label.setText(f"Loaded: {filepath}  [{num_frames} frames]")

    def _on_load_error(self, msg: str):
        self.status_label.setText(f"Error: {msg}")
        self.progress_bar.setVisible(False)
        QMessageBox.critical(self, "Load Error", msg)

    # ─────────────────────────────────────────
    # 파일 선택 / 프레임 전환
    # ─────────────────────────────────────────

    def _on_file_selected(self, spe_item: SpeFileItem, frame_idx: int):
        """파일 리스트에서 파일 선택 시"""
        frame = self._extract_frame(spe_item.spe_obj, frame_idx)
        if frame is not None:
            self.image_viewer.set_image_first(frame)
            self.status_label.setText(
                f"{spe_item.filename}  |  Frame {frame_idx + 1}/{spe_item.num_frames}"
                f"  |  {frame.shape[1]} x {frame.shape[0]}"
            )

    def _on_frame_changed(self, spe_item: SpeFileItem, frame_idx: int):
        """프레임 슬라이더 변경 시"""
        frame = self._extract_frame(spe_item.spe_obj, frame_idx)
        if frame is not None:
            self.image_viewer.set_image(frame)
            self.status_label.setText(
                f"{spe_item.filename}  |  Frame {frame_idx + 1}/{spe_item.num_frames}"
            )

    def _extract_frame(self, spe_obj, frame_idx: int) -> np.ndarray | None:
        """SPE 객체에서 프레임 추출 - 실제 클래스에 맞게 수정"""
        try:
            if hasattr(spe_obj, 'data'):
                data = spe_obj.data
                if isinstance(data, np.ndarray):
                    if data.ndim == 3:
                        return data[frame_idx]
                    return data
                elif hasattr(data, '__getitem__'):
                    return np.array(data[frame_idx])
            elif hasattr(spe_obj, 'get_frame'):
                return spe_obj.get_frame(frame_idx)
            elif hasattr(spe_obj, '__getitem__'):
                return np.array(spe_obj[frame_idx])
        except Exception as e:
            self.status_label.setText(f"Frame error: {e}")
        return None

    # ─────────────────────────────────────────
    # 프로파일 → 플롯 패널 연결
    # ─────────────────────────────────────────

    def _on_line_profile(self, data: np.ndarray):
        self.plot_panel.plot_line(data, label="Profile")
        self.plot_panel.set_xlabel("Pixel")
        self.plot_panel.set_ylabel("Intensity")

    def _on_box_profile(self, x_mean: np.ndarray, y_mean: np.ndarray):
        self.plot_panel.plot_two_lines(x_mean, y_mean, "X mean", "Y mean")
        self.plot_panel.set_xlabel("Pixel")
        self.plot_panel.set_ylabel("Mean Intensity")

    def _on_pixel_info(self, x: int, y: int, val: float):
        pass  # 필요 시 상태바 업데이트 등 추가

    # ─────────────────────────────────────────
    # 뷰 리셋
    # ─────────────────────────────────────────

    def _on_reset_view(self):
        self.image_viewer.image_view.autoRange()
