"""
plot_panel.py
프로파일 플롯 패널 - pyqtgraph PlotWidget 기반
QDockWidget으로 분리/부착 가능
"""

import numpy as np
import pyqtgraph as pg
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt


class PlotPanel(QWidget):
    """
    라인/박스/X/Y 프로파일을 표시하는 플롯 패널.
    """

    def __init__(self, title: str = "Profile", parent=None):
        super().__init__(parent)
        self._title = title
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # 상단 헤더 + 클리어 버튼
        header_row = QHBoxLayout()
        self.title_label = QLabel(self._title)
        self.title_label.setStyleSheet("color: #e94560; font-weight: bold; font-size: 11px; letter-spacing: 1px;")
        header_row.addWidget(self.title_label)
        header_row.addStretch()

        self.btn_clear = QPushButton("Clear")
        self.btn_clear.setFixedWidth(60)
        self.btn_clear.clicked.connect(self.clear)
        header_row.addWidget(self.btn_clear)
        layout.addLayout(header_row)

        # pyqtgraph PlotWidget
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('#16213e')
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget.getAxis('bottom').setPen('#0f3460')
        self.plot_widget.getAxis('left').setPen('#0f3460')
        self.plot_widget.getAxis('bottom').setTextPen('#a0a0b0')
        self.plot_widget.getAxis('left').setTextPen('#a0a0b0')
        layout.addWidget(self.plot_widget)

        # 현재 플롯 아이템들
        self._plot_items: list[pg.PlotDataItem] = []

        # 플롯 색상 순환
        self._colors = ['#e94560', '#4ecdc4', '#ffe66d', '#a8e6cf', '#ff8b94', '#c7ceea']
        self._color_idx = 0

    # ─────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────

    def plot_line(self, data: np.ndarray, label: str = "", clear_first: bool = True):
        """1D 프로파일 플롯"""
        if clear_first:
            self.clear()

        color = self._next_color()
        x = np.arange(len(data))
        item = self.plot_widget.plot(
            x, data,
            pen=pg.mkPen(color, width=1.5),
            name=label if label else None
        )
        self._plot_items.append(item)

    def plot_two_lines(self, data1: np.ndarray, data2: np.ndarray,
                       label1: str = "X mean", label2: str = "Y mean"):
        """두 개의 프로파일 동시 플롯 (박스 ROI용)"""
        self.clear()

        x1 = np.arange(len(data1))
        item1 = self.plot_widget.plot(
            x1, data1,
            pen=pg.mkPen('#e94560', width=1.5),
            name=label1
        )
        x2 = np.arange(len(data2))
        item2 = self.plot_widget.plot(
            x2, data2,
            pen=pg.mkPen('#4ecdc4', width=1.5),
            name=label2
        )
        self._plot_items.extend([item1, item2])

    def clear(self):
        """플롯 초기화"""
        self.plot_widget.clear()
        self._plot_items.clear()
        self._color_idx = 0

    def set_title(self, title: str):
        self.title_label.setText(title)

    def set_xlabel(self, label: str):
        self.plot_widget.setLabel('bottom', label)

    def set_ylabel(self, label: str):
        self.plot_widget.setLabel('left', label)

    # ─────────────────────────────────────────
    # Private
    # ─────────────────────────────────────────

    def _next_color(self) -> str:
        color = self._colors[self._color_idx % len(self._colors)]
        self._color_idx += 1
        return color
